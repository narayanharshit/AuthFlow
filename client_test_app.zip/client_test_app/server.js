const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3001;

// Parse JSON bodies
app.use(bodyParser.json());

// MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'naman',
    password: 'authflow',
    database: 'account_manager',
  });

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Server!');
});

// Serve your index.html file
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Sign in endpoint
app.post('/signin', (req, res) => {
    const { email, password } = req.body;
    const query = 'INSERT INTO accounts (email, password) VALUES (?, ?)';
    
    connection.query(query, [email, password], (err, results) => {
        if (err) throw err;
        res.json({ message: `Welcome, ${email}` });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
