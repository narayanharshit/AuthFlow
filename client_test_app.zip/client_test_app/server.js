// Author: Juhi Patel
// CMPSC 488: Capstone Project
// Date: 2/14/2024
// Client side server
// Last Updated: 2/20/2024

const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
// For connecting two local host
const cors = require('cors');
const crypto = require('crypto');

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());
// MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'naman',
    password: 'authflow',
    database: 'account_manager',
  });

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Server!');
});

// Serve your index.html file
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Sign in endpoint
app.post('/signin', (req, res) => {
    const { email, password } = req.body;
    // Use crypto to hash the password
    const hashPassword = crypto.createHash('sha256').update(password).digest('hex');
    // comparing the password from the stored password in the users database
    const query = 'SELECT password FROM users WHERE email = ?';
  
    connection.query(query, [email], (err, results) => {
      if (err) {
        console.error(err);
        // if there's any error
        res.status(500).json({ message: 'Error checking user credentials' });
      } else if (results.length > 0 && results[0].password === hashPassword) {
        // Password matches, now ask for passkey
        res.json({ message: 'Password verified, please enter your passkey', requirePasskey: true });
      } else {
        // user entered invalid email or password
        res.status(401).json({ message: 'Invalid email or password' });
      }
    });
  });
  

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
