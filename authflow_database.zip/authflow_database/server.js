const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const speakeasy = require('speakeasy');
const crypto = require('crypto');

// MySQL connection
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'naman',
  password: 'authflow',
  database: 'account_manager',
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the MySQL server.');
});

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('public')); 

app.post('/addAccount', (req, res) => {
  const { email, password } = req.body;
  // Generate a secret key for the user.
  const secret = speakeasy.generateSecret({length: 20});
  const token = speakeasy.totp({
    secret: secret.base32,
    encoding: 'base32'
  });

  // Hash the password using SHA-256
  const hashPassword = crypto.createHash('sha256').update(password).digest('hex');

  // Instead of inserting the plain password, insert the hashed password into the database.
  const query = 'INSERT INTO users (email, password, secret) VALUES (?, ?, ?)';
  
  connection.query(query, [email, hashPassword, secret.base32], (err, result) => {
    if (err) throw err;
    res.send({ message: 'Account added successfully', id: result.insertId });
  });
});

// Function to refresh passkey
const refreshPasskey = () => {
  const selectQuery = 'SELECT id, secret FROM users';
  connection.query(selectQuery, (err, results) => {
    if (err) console.error(err);
    else {
      results.forEach(user => {
        // Generate new token for each user
        const token = speakeasy.totp({
          secret: user.secret,
          encoding: 'base32'
        });

      console.log('Passkeys refreshed');
    }
 )};
}
)};

setInterval(refreshPasskey, 30000);

// Route to fetch emails and passkeys
app.get('/getEmails', (req, res) => {
  const query = 'SELECT email, secret FROM users';
  
  connection.query(query, (err, results) => {
    if (err) throw err;
    // Generate a passkey for each user on-the-fly
    const usersWithPasskeys = results.map(user => {
      const token = speakeasy.totp({
        secret: user.secret,
        encoding: 'base32'
      });
      return {
        email: user.email,
        passkey: token // Dynamically generated passkey
      };
    });
    res.send(usersWithPasskeys); 
  });
});



// Route to delete an account by email
app.delete('/deleteAccount', (req, res) => {
  const { email } = req.body;
  const query = 'DELETE FROM users WHERE email = ?';
  
  connection.query(query, [email], (err, result) => {
    if (err) throw err;
    res.send({ message: 'Account deleted successfully' });
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
