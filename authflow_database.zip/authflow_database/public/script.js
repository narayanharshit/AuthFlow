document.getElementById('addAccountBtn').addEventListener('click', () => {
    const accountForm = document.getElementById('accountForm');
    accountForm.style.display = 'block'; // Show the account form
});

document.getElementById('togglePassword').addEventListener('click', function () {
    const passwordInput = document.getElementById('passwordInput');
    if (this.checked) {
        passwordInput.type = 'text';
    } else {
        passwordInput.type = 'password';
    }
});

function addAccount(email, password) {
    fetch('/addAccount', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        document.getElementById('accountForm').style.display = 'none'; 
        fetchEmails(); 
    })
    .catch(error => console.error('Error:', error));
}

document.getElementById('emailInput').addEventListener('keypress', function(event) {
    if (event.key === "Enter") {
        submitForm();
    }
});

document.getElementById('passwordInput').addEventListener('keypress', function(event) {
    if (event.key === "Enter") {
        submitForm();
    }
});

function submitForm() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;
    
    if (email && password) {
        addAccount(email, password);
    }
}

document.getElementById('submitAccountBtn').addEventListener('click', submitForm);

function fetchEmails() {
    fetch('/getEmails')
    .then(response => response.json())
    .then(emails => {
        const emailsContainer = document.getElementById('emailsContainer');
        emailsContainer.innerHTML = ''; // Clear the container
        emails.forEach(email => {
            const div = document.createElement('div');
            div.className = 'account';
            div.innerHTML = `<span>${email.email}</span> <span class="passkey">${email.passkey}</span> <div class='timer'>30</div> <div class='progress-bar'></div> <button class="deleteBtn" onclick="deleteAccount('${email.email}')">Delete</button>`;
            emailsContainer.appendChild(div);
            startTimerAndProgressBar(div.querySelector('.timer'), div.querySelector('.progress-bar'), 30);
        });
    })
    .catch(error => console.error('Error fetching emails:', error));
}

function startTimerAndProgressBar(timerElement, progressBarElement, duration) {
    let timeLeft = duration;
    progressBarElement.style.width = '100%';
    progressBarElement.style.backgroundColor = '#6200ea';
    const interval = setInterval(() => {
        timeLeft--;
        timerElement.textContent = timeLeft.toString();
        progressBarElement.style.width = `${(timeLeft / duration) * 100}%`;
        if (timeLeft <= 0) {
            clearInterval(interval);
            fetchEmails(); // Refresh to get new passkeys and restart timers
        }
    }, 1000);
}


function deleteAccount(email) {
    if (!confirm(`Are you sure you want to delete the account for ${email}?`)) return;
    
    fetch('/deleteAccount', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(data.message);
        fetchEmails(); // Refresh the list
    })
    .catch(error => console.error('Error deleting account:', error));
}



// Initially fetch and display emails
fetchEmails();
